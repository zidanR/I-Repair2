<?php
include 'conn.php';

$id= @$_POST['id'];

$conn->query("DELETE FROM servis WHERE id_servis=".$id);

?>