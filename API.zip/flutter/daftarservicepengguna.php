<?php
include 'conn.php';

$kode_pesanan         = @$_POST['txtkode'];    
$nama_akun			  = @$_POST['txtakun'];
$jenis_motor	      = @$_POST['txtjenis'];
$keluhan			  = @$_POST['txtkeluhan'];
$tanggal       		  = @$_POST['txttgl'];


$conn->query("INSERT INTO servis (nama_akun,jenis_motor,keluhan,tanggal) VALUES ('".$kode_pesanan."','".$nama_akun."','".$jenis_motor."','".$keluhan."','".$tanggal."')");

?>