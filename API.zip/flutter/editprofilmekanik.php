<?php
include 'conn.php';

$id	    	          = @$_POST['txtid'];
$nama_akun			  = @$_POST['txtnamaakun'];
$jenis_motor	      = @$_POST['txtusernames'];
$keluhan			  = @$_POST['txtpasswords'];
$tanggal       		  = @$_POST['txtalamat'];
$Rating               = @$_POST['txttelepon'];

$conn->query("UPDATE user SET nama_user='".$nama_akun."',usernames='".$jenis_motor."',passwords='".$keluhan."',alamat='".$tanggal."',nomro_telepon='".$Rating."' WHERE id_servis=".$id);

?>