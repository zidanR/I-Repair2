<?php
// date_default_timezone_set('Asia/Jakarta');
// header('Content-Type: application/json; charset=utf8');
$conn = mysqli_connect 
   (
   "localhost",
   "bengkeli_admin",
   "C~!1cCF7E~Y&",
   "bengkeli_irepair2");

if (mysqli_connect_errno())
{
echo "Koneksi Gagal".mysqli_connect_error();
}
$base_url="http://localhost/irepair2/";
?>