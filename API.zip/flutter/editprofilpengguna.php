<?php
include 'conn.php';

$id	    	          = @$_POST['txtid'];
$nama_akun			  = @$_POST['txtnamapeng'];
$jenis_motor	      = @$_POST['txtusernamepeng'];
$keluhan			  = @$_POST['txtpasswords'];
$tanggal       		  = @$_POST['txtemail'];
$Rating               = @$_POST['txtalamat'];
$Ratingg              = @$_POST['txttelp'];

$conn->query("UPDATE pengguna SET nama_pengguna='".$nama_akun."',username_pengguna='".$jenis_motor."',passwords='".$keluhan."',email='".$tanggal."',alamat='".$Rating."',nomro_telepon='".$Ratingg."' WHERE id_pengguna=".$id);

?>