<?php
include 'conn.php';

$chat = @$_POST['chat'];

$conn->query("INSERT INTO chat (mekanik) VALUES ('".$chat."')");

?>