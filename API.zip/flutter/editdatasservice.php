<?php
include 'conn.php';

$id= @$_POST['id'];
$pergantian_sparepart = @$_POST['txtsparepart'];
$status_mekanik       = @$_POST['status_mekanik'];
$total_biaya          = @$_POST['total_biaya'];


$conn->query("UPDATE servis SET pergantian_sparepart='".$pergantian_sparepart."',status_mekanik='".$status_mekanik."',total_biaya='".$total_biaya."' WHERE id_servis=".$id);

?>