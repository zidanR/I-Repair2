<?php
include 'conn.php';

$nama_pengguna	    = @$_POST['txtnama'];
$username_pengguna	= @$_POST['txtpengguna'];
$passwords 	        = md5(@$_POST['txtpass']);
$level	            = @$_POST['txtlevel'];
$email	            = @$_POST['txtemail'];
$alamat	            = @$_POST['txtalamat'];
$nomor_telepon	    = @$_POST['txtnomer'];

$conn->query("INSERT INTO pengguna (nama_pengguna,username_pengguna,passwords,email,level,alamat,nomor_telepon) VALUES ('".$nama_pengguna."','".$username_pengguna."','".$passwords."','".$email."','".$level."','".$alamat."','".$nomor_telepon."')");

?>

