<?php
include 'conn.php';

$usernames = @$_POST['usernames'];
$passwords = md5(@$_POST['passwords']);

$queryResult = $conn->query("SELECT * FROM user WHERE usernames='".$usernames."'and passwords='".$passwords."'");

$result=array();

while($fetchData = $queryResult->fetch_assoc()){
	$result[]=$fetchData;
}

echo json_encode($result);

?>