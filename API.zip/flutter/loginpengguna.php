<?php
include 'conn.php';

// $idpengguna= @$_POST['idpengguna'];
$usernamepengguna = @$_POST['username'];
$passwords = md5(@$_POST['password']);
// $level= @$_POST['level'];

$queryResult = $conn->query("SELECT * FROM pengguna WHERE username_pengguna='".$usernamepengguna."'and passwords='".$passwords."'");

$result=array();

while($fetchData = $queryResult->fetch_assoc()){
	$result[]=$fetchData;
}

echo json_encode($result);

?>