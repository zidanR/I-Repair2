<?php
include 'conn.php';

$id	    	          = @$_POST['txtid'];
$nama_akun			  = @$_POST['txtakun'];
$jenis_motor	      = @$_POST['txtjenis'];
$keluhan			  = @$_POST['txtkeluhan'];
$tanggal       		  = @$_POST['txttgl'];
$Rating               = @$_POST['Rating'];

$conn->query("UPDATE servis SET nama_akun='".$nama_akun."',jenis_motor='".$jenis_motor."',keluhan='".$keluhan."',tanggal='".$tanggal."',Rating='".$Rating."' WHERE id_servis=".$id);

?>